# EV-217 — raw capture placeholder

Origin: community-ugc (registry.npmjs.org + api.github.com via gh api; fetch_page outage fallback)

Raw HTML could not be persisted in this environment due to TLS egress restrictions to non-GitHub hosts.
The structured summary is in docs/continuity/a7e23a6b/evidence/index.jsonl and the EV extract markdown file in docs/continuity/a7e23a6b/evidence/extract/.
To backfill this file, refetch from the source URL once TLS is available.
