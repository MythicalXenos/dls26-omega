# EV-226 — raw capture placeholder

Origin: official-support (14369944135058) captured on branch arena/22655f48-dls26-omega

Raw HTML could not be persisted in this environment due to TLS egress restrictions to non-GitHub hosts.
The structured summary is in docs/continuity/a7e23a6b/evidence/index.jsonl and the EV extract markdown file in docs/continuity/a7e23a6b/evidence/extract/.
To backfill this file, refetch from the source URL once TLS is available.
