# KB — SOURCE FAMILIES, SUPPORT INVENTORY & INCENTIVE SCREEN

> **DERIVED VIEW — not the claim authority.** The live claim authority is `kb/claims.jsonl` (see `kb/claims_index.md`). This file is a topic summary retained for narrative context; where it disagrees with a claim record, the claim record wins.
Captured 2026-10-17 (turn 2). Per OMEGA-FRONTIER-001 and the FTG SUPPORT / ZENDESK SOURCE-FAMILY RULE.

## S-001 FTG official support portal — canonical DLS FAQ inventory (support.ftgames.com, Zendesk)
Section "Dream League Soccer FAQs" (id 203117809), fetched 2026-10-17 — 30 articles:
1. When will the next app update be? (360000262229)
2. How do the various player stats in DLS affect gameplay? (360019166777) ← HIGH VALUE, fetch next
3. How is save data stored and transferred in DLS? (4413273241873)
4. How do I find my User ID? (37082887837202)
5. Removal of Facebook Login from DLS (9804887423121)
6. Can I use my Dream League Soccer (formerly DLS19) profile in DLS25? (360004717278)
7. Why does the app require a connection to play? (360004034498)
8. Is my device compatible with the app? (214385685)
9. Why can't I update the app? (360000220945)
10. What is the Season Pass? (4404070913169)
11. What is the Prize Ladder? (23108987826962)
12. What are Dream Point Boosts? (24081168829330)
13. What are Clans? (30839289076626)
14. How do I play a Friend Match? (360019064438)
15. How do I restart my career from the beginning? (213851909)
16. I am not seeing any video clips, what can I do? (360017166918)
17. How can I reduce my mobile data usage? (360005680437)
18. Why doesn't my player look like the real person? (360004718318)
19. How do I hide the text on the control buttons? (14369944135058)
20. How do I customise my kit/logo? (360004080497)
21. How do I obtain more players? (360004066417)
22. How do I change my manager? (360003945937)
23. How does game difficulty work? (360018360418)
24. What are Leaderboards? (360003914998)
25. How does Dream League Live matchmaking work? (360018359998) — FETCHED, full text in KB (terminology T-013)
26. How do I change my emojis in Dream League Live? (360020938198)
27. Can my opponent see my custom kit and logo in Dream League Live? (360021064298)
28. Multiplayer Troubleshooting (360004222118)
29. How do I earn coins in the app? (214385285)
30. Is it possible to earn free coins? (213851369)
Portal sections: Dream League Soccer FAQs; Score Hero FAQs; Ultimate Draft Soccer (newer FTG title — note); Score Match FAQs.

## S-002 Incentive-screen registry (deception register — assessments, not bans)
- thesoccerera.com — internal date contradictions (launch availability); traffic incentive; low-credibility for dates/versions.
- playdreamleaguesoccer.com — fabricated-style named user quotes ("GoalMachine_23 (Bangalore)"); unreliable; affiliate/mod incentive suspected.
- mokoweb.com, dlsmod.com, modyolo.com, liteapks.com — mod distribution; ToS/ban-risk surface (FTG support hosts "Why have I been blocked from playing DLS?" as evidence blocking exists); version data usable only where corroborated elsewhere.
- sportsdunia.com, ggbro.io, fifaworldcupnews.com, dlskits.mobi — content farms; Community Consensus ceiling; never sole source for Confirmed.
- sakibpro.com — tool site; tool-derived claims only.
- appmagic/appbrain/appglint/soft112/cepde/gameeroid — store-metric mirrors; derive from store data, not independent of each other.
- es.wikipedia.org, vi.wikipedia.org — encyclopedia; community-edited, useful for franchise history.

## S-003 NON_CONNECTED (different games — never-assume-shared-mechanics rule)
ezarena.com and itemd2r.com (EA Sports FC 26), fm26tactics.com (Football Manager 26). Excluded from DLS knowledge; scope evidence: different titles/publishers.

## S-004 Source-type coverage matrix (2026-10-17)
- Official sources: COVERED (store listings, FTG support portal, FTG TikTok, FTG X).
- Third-party databases/tools: COVERED (APKMirror, APKCombo, AppBrain, AppMagic, sakibpro, dlsinside [PARTIAL — client-rendered player rows not extractable this turn], dlskits.mobi [snippet only]).
- English-language community: COVERED (r/DreamLeagueSoccer, gamingonphone, ggbro).
- Non-English community: PARTIAL (es.wikipedia, vi.wikipedia, Turkish listings, Portuguese TikTok, Hindi YouTube) — true non-English forums still owed.
- Technical sources: PARTIAL (APKMirror static variant data; no decompilation yet — Step 2).
- User-generated content: PARTIAL (YouTube videos, TikTok discover).
- Walls identified: dlsinside JS-rendered content; Reddit full thread bodies (snippets only so far); no user account/community access.

## Turn-3 additions (2026-10-17)
- S-001 extension — FTG DLS FAQ articles fetched in full this turn: player stats in gameplay (360019166777), Prize Ladder (23108987826962), Season Pass (4404070913169), Clans (30839289076626), game difficulty (360018360418), Dream Point Boosts (24081168829330), obtain more players (360004066417), get Gems (360003914938), next app update (360000262229). Newly discovered articles (title known, body owed): How do I develop my players? (360003914778 — partially captured via search snippet: coaches random permanent upgrades, Form Boost temporary scaled by Training facilities), How do I earn coins in the app? (214385285), Is it possible to earn free coins? (213851369), How is save data stored and transferred? (4413273241873), How do I play a Friend Match? (360019064438), Multiplayer Troubleshooting (360004222118), Why have I been blocked from playing DLS? (360008904718), and the remaining section-list articles.
- S-002 additions: relaxmodapk.com (mod distribution — screened); sakibpro.com "100% Official" self-labeling noted (unverified claim of officiality — traffic incentive; its Season-Pass/Cult-Heroes claim treated as community-tier).
- S-004 update: official sources DEEP (10 FTG articles captured); non-English community extended (Indonesian App Store listing id, Vietnamese kit site kitdls.net, Iranian Cafebazaar, French/Portuguese store copies); technical unchanged (no decompilation — Step 2).

## Turn-4 additions (2026-10-17)
- S-001 extension — 15 more FTG DLS articles fetched in full: develop my players (360003914778), earn coins (214385285), earn free coins (213851369), save data stored/transferred (4413273241873), blocked from playing DLS (360008904718), Leaderboards (360003914998), Friend Match (360019064438), restart career / Reset Profile (213851909), connection requirement (360004034498), device compatibility (214385685), update the app (360000220945), Facebook Login removal (9804887423121), DLS19 profile in DLS25 (360004717278), customise kit/logo (360004080497), change my manager (360003945937). Running total: 25 of 30 section-listed articles captured. Newly discovered articles (title known, body owed): Why are some players missing from the app? (213852049), Can I sell my players? (360003945617), How do I sell players? (1714655181585), How do I have my personal data deleted? (360017046578), How can I change my graphics settings? (360005984437), Age Confirmation & Personal Ads and Notifications (440824982260), How do I change my kit? (791695913473). Remaining section-listed bodies owed: video clips (360017166918), data usage (360005680437), player likeness (360004718318), control-button text (14369944135058), DLL emojis (360020938198), kit visibility in DLL (360021064298), Multiplayer Troubleshooting (360004222118), User ID (37082887837202).
- S-002 additions: sikayetvar.com (Turkish complaint platform — genuine non-English community surface; single-complaint weight, Speculative-tier use).
- S-004 update: official sources DEEP (25 FTG articles captured in full). Non-English community extended further (Turkish complaint platform sikayetvar.com; Turkish-playstyle Reddit thread; DLS26 launch megathreads). dlsinside.com homepage identified as carrying a canonical "Latest versions" table (version-code ↔ version ↔ date mapping, e.g. 160-13430, 159-13420, 158-13410, 154-13350) — fetch owed; its dates skew ~1 day vs APKMirror (own processing dates).

## Turn 6–7 coverage refresh — this environment (2026-10-17)
This section supersedes the "COVERED / PARTIAL" labels in S-004 **for this environment generation only**. Historic captures remain valid as evidence; what changed is reachability.

- **Official sources:** support.ftgames.com and firsttouchgames.zendesk.com **blocked at TLS** (curl 35) from this sandbox — S-055/S-056. Captured corpus: 26 of 30 section-listed articles (22 with EV records; 4 summary-only), plus 13 additionally-discovered articles. Owed: 3 bodies (#19 control-button text, #26 DLL emojis, #27 opponent kit visibility) and a moved update-troubleshooting slug.
- **Third-party databases/tools:** dlsinside.com **blocked** — S-057. Historic extractions held (version table, special-card taxonomy counts, sakibpro pricing/simulator claims). No live refresh possible.
- **English-language community:** Reddit, gamingonphone, thesoccerera, sportsdunia, dlskits, z2u, bluestacks, mwm — all **blocked** in this environment; 8 refs sit snippet-only.
- **Non-English community:** ES/VI/TR/ID/PT sources all **blocked**; 3 ES + 1 VI refs snippet-only.
- **Technical sources:** GitHub (repos, code search) and npm/pypi reachable — S-059…S-062. Result: **negative** for DLS26 APK, save-format, stat-table or decompilation corpora on these families. No java/ADB/APK tooling in the sandbox, so decompilation is also capability-blocked, not merely unfound.
- **User-generated content:** TikTok/YouTube **blocked**; historic partial captures only.
- **Repository family (new):** GitHub as a *source family* is reachable and was swept; GitHub as a *transport* is also the publication path. These are different uses of one host and are kept distinct.
- **Environment control probe:** a single unrelated host also failed at TLS (S-058), which is what establishes the boundary as destination policy rather than a targeted site outage. Per OMEGA-RETRIEVAL-001 no second diagnostic was run.

**Net position:** no source type is *untouched*, and three are blocked rather than unread. The epoch's limiting factor is access, not effort or scope.
